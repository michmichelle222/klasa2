const liczba_celsjuszy = document.querySelector('#C');
const wynik = document.querySelector('#wynik');
const btn = document.querySelector("button");

btn.addEventListener('click' , function (){
    let c = parseFloat(liczba_celsjuszy.value);

    let k = c + 273.15;
    let f = c * 1.8 + 32;

    wynik.innerHTML =
        `
        wynik obliczeń dla : T <sub>Celsiusz :</sub> ${c} <br>
        T <sub>Kelwin :</sub> ${k} <br>
        T <sub>Fahrenheit :</sub> ${f} <br>
        
        `
})
